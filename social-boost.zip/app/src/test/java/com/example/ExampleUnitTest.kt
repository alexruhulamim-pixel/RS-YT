package com.example

import com.example.data.content.ViralToolsData
import com.example.data.content.GrowthGuidesData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testViralTitlesGeneration() {
        val titles = ViralToolsData.generateViralTitles("ফ্রি ফায়ার", "YOUTUBE")
        assertEquals(5, titles.size)
        assertTrue(titles.first().first.contains("ফ্রি ফায়ার"))
    }

    @Test
    fun testHashtagPacksNotEmpty() {
        assertFalse(ViralToolsData.hashtagPacks.isEmpty())
        val fbPack = ViralToolsData.hashtagPacks.find { it.platform == "FACEBOOK" }
        assertTrue(fbPack != null && fbPack.hashtags.isNotEmpty())
        val tiktokPack = ViralToolsData.hashtagPacks.find { it.platform == "TIKTOK" }
        assertTrue(tiktokPack != null && tiktokPack.hashtags.contains("#fyp"))
    }

    @Test
    fun testGrowthGuidesData() {
        assertEquals(5, GrowthGuidesData.guides.size)
        val tiktokGuide = GrowthGuidesData.guides.find { it.id == "tiktok_1m_roadmap" }
        assertTrue(tiktokGuide != null && tiktokGuide.stepsBn.isNotEmpty())
    }
}
