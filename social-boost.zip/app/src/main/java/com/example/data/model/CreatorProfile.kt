package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "creators")
data class CreatorProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val platform: String, // "YOUTUBE" or "FACEBOOK"
    val channelOrPageName: String,
    val handleOrUrl: String,
    val category: String, // "Tech", "Gaming", "Vlog", "Comedy", "Education", "Islamic", "Cooking", "Lifestyle"
    val currentSubscribersOrFollowers: String,
    val description: String,
    val rewardCredits: Int = 30,
    val isUserChannel: Boolean = false,
    val boostActive: Boolean = false,
    val allocatedCoins: Int = 0,
    val impressionsDelivered: Int = 0,
    val followsOrSubsDelivered: Int = 0,
    val isSupportedByUser: Boolean = false,
    val badge: String = "Popular" // "Top Creator", "Rising Star", "Verified", "Sponsored", "Trending"
)
