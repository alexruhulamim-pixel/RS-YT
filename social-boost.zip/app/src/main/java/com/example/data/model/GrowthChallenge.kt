package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "challenges")
data class GrowthChallenge(
    @PrimaryKey
    val id: String,
    val titleBn: String,
    val titleEn: String,
    val descBn: String,
    val descEn: String,
    val rewardCredits: Int,
    val targetCount: Int = 1,
    val currentCount: Int = 0,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val iconType: String = "ROCKET" // "VISIT", "SHARE", "BOOST", "TAGS", "HOOK"
)
