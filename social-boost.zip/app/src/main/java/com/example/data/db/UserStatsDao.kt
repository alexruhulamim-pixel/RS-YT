package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.UserStats
import kotlinx.coroutines.flow.Flow

@Dao
interface UserStatsDao {
    @Query("SELECT * FROM user_stats WHERE id = 1")
    fun getUserStats(): Flow<UserStats?>

    @Query("SELECT * FROM user_stats WHERE id = 1")
    suspend fun getUserStatsOnce(): UserStats?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefaultStats(stats: UserStats)

    @Update
    suspend fun updateStats(stats: UserStats)

    @Query("UPDATE user_stats SET credits = credits + :amount WHERE id = 1")
    suspend fun addCredits(amount: Int)

    @Query("UPDATE user_stats SET credits = CASE WHEN credits >= :amount THEN credits - :amount ELSE credits END WHERE id = 1")
    suspend fun deductCredits(amount: Int)

    @Query("UPDATE user_stats SET language = :lang WHERE id = 1")
    suspend fun updateLanguage(lang: String)
}
