package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.CreatorProfile
import com.example.data.model.GrowthChallenge
import com.example.data.model.SavedItem
import com.example.data.model.UserStats
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import kotlin.random.Random

class GrowthRepository(private val database: AppDatabase) {

    private val creatorDao = database.creatorDao()
    private val userStatsDao = database.userStatsDao()
    private val challengeDao = database.growthChallengeDao()
    private val savedItemDao = database.savedItemDao()

    val allCreators: Flow<List<CreatorProfile>> = creatorDao.getAllCreators()
    val userCampaigns: Flow<List<CreatorProfile>> = creatorDao.getUserCampaigns()
    val userStats: Flow<UserStats?> = userStatsDao.getUserStats()
    val allChallenges: Flow<List<GrowthChallenge>> = challengeDao.getAllChallenges()
    val savedItems: Flow<List<SavedItem>> = savedItemDao.getAllSavedItems()

    suspend fun initializeSeedDataIfNeeded() {
        val currentStats = userStatsDao.getUserStatsOnce()
        if (currentStats == null) {
            userStatsDao.insertDefaultStats(
                UserStats(
                    id = 1,
                    credits = 10000,
                    totalFollowersDelivered = 48,
                    totalSubscribersDelivered = 75,
                    completedTasksCount = 0,
                    language = "bn"
                )
            )
        } else if (currentStats.credits < 5000) {
            userStatsDao.addCredits(10000)
        }

        val seedCreators = listOf(
            CreatorProfile(
                platform = "YOUTUBE",
                channelOrPageName = "Tech Bangla Master",
                handleOrUrl = "https://www.youtube.com/@techbangla",
                category = "Tech",
                currentSubscribersOrFollowers = "142K",
                description = "Android টিপস, গ্যাজেট রিভিউ এবং ইউটিউব গ্রোথ ট্রিকস প্রতিদিন।",
                rewardCredits = 40,
                badge = "Verified",
                boostActive = true
            ),
            CreatorProfile(
                platform = "FACEBOOK",
                channelOrPageName = "Bangla Natok & Entertainment",
                handleOrUrl = "https://www.facebook.com",
                category = "Comedy",
                currentSubscribersOrFollowers = "310K",
                description = "হাস্যরসাত্মক শর্ট ভিডিও ও ফানি রিলস নিয়ে নিয়মিত এন্টারটেইনমেন্ট।",
                rewardCredits = 35,
                badge = "Trending",
                boostActive = true
            ),
            CreatorProfile(
                platform = "YOUTUBE",
                channelOrPageName = "Deshi Gaming Zone",
                handleOrUrl = "https://www.youtube.com",
                category = "Gaming",
                currentSubscribersOrFollowers = "89K",
                description = "Free Fire ও PUBG লাইভ স্ট্রিম ও প্রো প্লেয়ার গেমপ্লে হাইলাইটস।",
                rewardCredits = 45,
                badge = "Rising Star",
                boostActive = true
            ),
            CreatorProfile(
                platform = "FACEBOOK",
                channelOrPageName = "Village Food & Cooking BD",
                handleOrUrl = "https://www.facebook.com",
                category = "Cooking",
                currentSubscribersOrFollowers = "520K",
                description = "গ্রামের সুস্বাদু ঐতিহ্যবাহী রান্নার চমৎকার ভিডিও ও রেসিপি।",
                rewardCredits = 35,
                badge = "Top Creator",
                boostActive = true
            ),
            CreatorProfile(
                platform = "YOUTUBE",
                channelOrPageName = "Daily Motivation Bangla",
                handleOrUrl = "https://www.youtube.com",
                category = "Education",
                currentSubscribersOrFollowers = "67K",
                description = "জীবন গড়ার অনুপ্রেরণামূলক উক্তি ও সাফল্যের শর্টস ভিডিও।",
                rewardCredits = 30,
                badge = "Popular",
                boostActive = false
            ),
            CreatorProfile(
                platform = "FACEBOOK",
                channelOrPageName = "Islamic Life BD",
                handleOrUrl = "https://www.facebook.com",
                category = "Islamic",
                currentSubscribersOrFollowers = "240K",
                description = "দৈনন্দিন ইসলামিক জ্ঞান, দোয়া ও সুন্দর নসিহত।",
                rewardCredits = 30,
                badge = "Popular",
                boostActive = false
            ),
            CreatorProfile(
                platform = "TIKTOK",
                channelOrPageName = "TikTok Fun & Comedy BD",
                handleOrUrl = "https://www.tiktok.com",
                category = "Comedy",
                currentSubscribersOrFollowers = "850K",
                description = "ভাইরাল ফানি ডুয়েট ও ট্রেন্ডিং টিকটক ভিডিও।",
                rewardCredits = 40,
                badge = "Trending",
                boostActive = true
            ),
            CreatorProfile(
                platform = "TIKTOK",
                channelOrPageName = "Deshi TikTok Beats",
                handleOrUrl = "https://www.tiktok.com",
                category = "Music",
                currentSubscribersOrFollowers = "420K",
                description = "ট্রেন্ডিং বাংলাদেশি মিউজিক ও লিপসিঙ্ক ভিডিও।",
                rewardCredits = 35,
                badge = "Rising Star",
                boostActive = false
            ),
            CreatorProfile(
                platform = "YOUTUBE",
                channelOrPageName = "Vlog with Tanvir",
                handleOrUrl = "https://www.youtube.com",
                category = "Vlog",
                currentSubscribersOrFollowers = "53K",
                description = "বাংলাদেশ ও আন্তর্জাতিক ভ্রমণ অভিজ্ঞতা ও লাইফস্টাইল ভ্লগ।",
                rewardCredits = 40,
                badge = "Rising Star",
                boostActive = false
            ),
            CreatorProfile(
                platform = "FACEBOOK",
                channelOrPageName = "Creative Graphics BD",
                handleOrUrl = "https://www.facebook.com",
                category = "Tech",
                currentSubscribersOrFollowers = "95K",
                description = "ফটোশপ, থাম্বনেইল ডিজাইন ও ফ্রিল্যান্সিং গাইডলাইন।",
                rewardCredits = 35,
                badge = "Verified",
                boostActive = false
            )
        )
        creatorDao.insertInitialCreators(seedCreators)

        val seedChallenges = listOf(
            GrowthChallenge(
                id = "c_visit_yt",
                titleBn = "৩টি ইউটিউব চ্যানেল ভিজিট করুন",
                titleEn = "Visit 3 YouTube Channels",
                descBn = "কমিউনিটি থেকে ৩টি চ্যানেলে যান এবং তাদের সাপোর্ট করুন",
                descEn = "Visit and support 3 creator channels from the community feed",
                rewardCredits = 100,
                targetCount = 3,
                iconType = "VISIT"
            ),
            GrowthChallenge(
                id = "c_visit_fb",
                titleBn = "২টি ফেসবুক পেজ ফলো করুন",
                titleEn = "Follow 2 Facebook Pages",
                descBn = "কমিউনিটি পেজে গিয়ে ফলো দিয়ে সাপোর্ট দিন",
                descEn = "Visit and follow 2 creator Facebook pages",
                rewardCredits = 80,
                targetCount = 2,
                iconType = "VISIT"
            ),
            GrowthChallenge(
                id = "c_gen_title",
                titleBn = "১টি ভাইরাল টাইটেল তৈরি করুন",
                titleEn = "Generate 1 Viral Title",
                descBn = "AI টুলস দিয়ে আপনার পছন্দের বিষয়ের টাইটেল বানান",
                descEn = "Use the Title Generator to create a high-CTR headline",
                rewardCredits = 50,
                targetCount = 1,
                iconType = "HOOK"
            ),
            GrowthChallenge(
                id = "c_copy_tags",
                titleBn = "১টি ট্রেন্ডিং হ্যাশট্যাগ প্যাক কপি করুন",
                titleEn = "Copy 1 Trending Hashtag Pack",
                descBn = "আপনার ফেসবুক রিলস বা ইউটিউব শর্টসের জন্য ট্যাগ নিন",
                descEn = "Copy trending tags to boost your Reels or Shorts reach",
                rewardCredits = 50,
                targetCount = 1,
                iconType = "TAGS"
            ),
            GrowthChallenge(
                id = "c_spin",
                titleBn = "লাকি স্পিন হুইল ঘুরান",
                titleEn = "Spin the Lucky Wheel",
                descBn = "স্পিন করে ফ্রি বোনাস কয়েন অর্জন করুন",
                descEn = "Spin to win free unlimited reward credits",
                rewardCredits = 60,
                targetCount = 1,
                iconType = "ROCKET"
            ),
            GrowthChallenge(
                id = "c_add_campaign",
                titleBn = "আপনার চ্যানেল/পেজ বুস্ট লিস্টে যুক্ত করুন",
                titleEn = "Promote Your Channel or Page",
                descBn = "আপনার নিজের চ্যানেল যুক্ত করে আনলিমিটেড ফলোয়ার/সাবস্ক্রাইবার নিন",
                descEn = "Add your own link to the spotlight showcase to gain followers",
                rewardCredits = 250,
                targetCount = 1,
                iconType = "BOOST"
            )
        )
        challengeDao.insertDefaultChallenges(seedChallenges)
    }

    suspend fun supportCreator(creator: CreatorProfile): Int {
        val earned = creator.rewardCredits
        creatorDao.markAsSupported(creator.id)
        userStatsDao.addCredits(earned)

        if (creator.platform == "YOUTUBE") {
            challengeDao.incrementChallengeProgress("c_visit_yt")
        } else {
            challengeDao.incrementChallengeProgress("c_visit_fb")
        }

        // Deliver extra impressions to user's active boosted campaigns
        creatorDao.incrementBoostImpressions()
        return earned
    }

    suspend fun createOrBoostUserCampaign(
        platform: String,
        name: String,
        url: String,
        category: String,
        allocatedCoins: Int,
        description: String
    ): Boolean {
        val currentStats = userStatsDao.getUserStatsOnce() ?: return false
        if (currentStats.credits < allocatedCoins) return false

        userStatsDao.deductCredits(allocatedCoins)

        val newCampaign = CreatorProfile(
            platform = platform,
            channelOrPageName = name,
            handleOrUrl = url,
            category = category,
            currentSubscribersOrFollowers = "Growing Fast",
            description = description.ifBlank { "Support my channel and I support you back!" },
            rewardCredits = 40,
            isUserChannel = true,
            boostActive = true,
            allocatedCoins = allocatedCoins,
            impressionsDelivered = Random.nextInt(15, 45),
            followsOrSubsDelivered = Random.nextInt(5, 15),
            badge = "Boost Active"
        )
        creatorDao.insertCreator(newCampaign)
        challengeDao.incrementChallengeProgress("c_add_campaign")
        return true
    }

    suspend fun claimDailyReward(): Pair<Boolean, Int> {
        val todayEpochDay = LocalDate.now().toEpochDay()
        val stats = userStatsDao.getUserStatsOnce() ?: return Pair(false, 0)

        if (stats.lastDailyClaimEpochDay >= todayEpochDay) {
            return Pair(false, 0)
        }

        val bonus = 150
        val updated = stats.copy(
            credits = stats.credits + bonus,
            lastDailyClaimEpochDay = todayEpochDay
        )
        userStatsDao.updateStats(updated)
        return Pair(true, bonus)
    }

    suspend fun spinLuckyWheel(): Int {
        val possibleWins = listOf(50, 100, 150, 200, 300, 500)
        val prize = possibleWins.random()

        userStatsDao.addCredits(prize)
        challengeDao.incrementChallengeProgress("c_spin")
        return prize
    }

    suspend fun claimChallengeReward(challenge: GrowthChallenge): Boolean {
        if (!challenge.isCompleted || challenge.isClaimed) return false
        challengeDao.markAsClaimed(challenge.id)
        userStatsDao.addCredits(challenge.rewardCredits)
        return true
    }

    suspend fun toggleLanguage() {
        val stats = userStatsDao.getUserStatsOnce() ?: return
        val newLang = if (stats.language == "bn") "en" else "bn"
        userStatsDao.updateLanguage(newLang)
    }

    suspend fun recordToolAction(actionType: String) {
        if (actionType == "TITLE") {
            challengeDao.incrementChallengeProgress("c_gen_title")
        } else if (actionType == "TAGS") {
            challengeDao.incrementChallengeProgress("c_copy_tags")
        }
    }

    suspend fun saveItem(type: String, platform: String, category: String, content: String) {
        savedItemDao.insertSavedItem(
            SavedItem(
                type = type,
                platform = platform,
                category = category,
                content = content
            )
        )
    }

    suspend fun deleteSavedItem(id: Long) {
        savedItemDao.deleteSavedItem(id)
    }

    suspend fun deleteCampaign(id: Long) {
        creatorDao.deleteCreator(id)
    }

    suspend fun addUnlimitedCoins(amount: Int = 10000) {
        userStatsDao.addCredits(amount)
    }
}
