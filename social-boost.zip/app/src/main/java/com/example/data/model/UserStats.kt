package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_stats")
data class UserStats(
    @PrimaryKey
    val id: Int = 1,
    val credits: Int = 200, // Starting bonus
    val totalFollowersDelivered: Int = 0,
    val totalSubscribersDelivered: Int = 0,
    val completedTasksCount: Int = 0,
    val lastDailyClaimEpochDay: Long = 0,
    val spinsUsedToday: Int = 0,
    val lastSpinEpochDay: Long = 0,
    val language: String = "bn" // "bn" for Bengali, "en" for English
)
