package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_items")
data class SavedItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "TITLE", "HASHTAGS", "TAGS"
    val platform: String, // "FACEBOOK", "YOUTUBE", "BOTH"
    val category: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
