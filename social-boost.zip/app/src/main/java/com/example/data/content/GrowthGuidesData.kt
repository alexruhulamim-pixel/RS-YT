package com.example.data.content

data class GrowthGuide(
    val id: String,
    val platform: String, // "FACEBOOK", "YOUTUBE", "BOTH"
    val titleBn: String,
    val titleEn: String,
    val subtitleBn: String,
    val subtitleEn: String,
    val readTime: String,
    val stepsBn: List<String>,
    val stepsEn: List<String>,
    val proTipBn: String,
    val proTipEn: String,
    val category: String
)

object GrowthGuidesData {
    val guides = listOf(
        GrowthGuide(
            id = "fb_reels_viral",
            platform = "FACEBOOK",
            titleBn = "ফেসবুক রিলস ভাইরাল করার গোপন অ্যালগরিদম ট্রিক",
            titleEn = "Facebook Reels Viral Algorithm Secret Method",
            subtitleBn = "অল্প সময়ে লাখ লাখ ভিউ এবং আনলিমিটেড ফলোয়ার পাওয়ার উপায়",
            subtitleEn = "How to generate millions of views and massive followers rapidly",
            readTime = "3 min read",
            stepsBn = listOf(
                "ভিডিওর প্রথম ৩ সেকেন্ডে আকর্ষণীয় হুক (Hook) দিন—যেমন 'এই ভুলটি আপনিও করছেন না তো?'।",
                "ভিডিও দৈর্ঘ্য সবসময় ৭ থেকে ১৫ সেকেন্ডের মধ্যে রাখুন। ছোট ভিডিও মানুষ বারবার দেখলে রিটেনশন ২০০%+ হয়।",
                "ভিডিও পোস্ট করার সময় ক্যাপশনে লিঙ্ক দেবেন না। লিঙ্ক কমেন্ট বক্সে পিন করুন।",
                "অরিজিনাল সাউন্ড ও ট্রেন্ডিং মিউজিক ব্যবহার করুন।",
                "প্রতিদিন নির্দিষ্ট সময়ে (দুপুর ১টা অথবা রাত ৮টা থেকে ১০টা) কমপক্ষে ২টি রিলস আপলোড করুন।"
            ),
            stepsEn = listOf(
                "Deliver a punchy hook in the first 3 seconds (e.g., 'Are you making this huge mistake?').",
                "Keep Reels between 7-15 seconds. Looping viewers push watch retention above 200%.",
                "Never put external links in the reel description—pin it in the top comment instead.",
                "Use trending background audio tracks paired with original commentary.",
                "Post consistently at peak active hours (1:00 PM or 8:00 PM - 10:00 PM) with 2 reels daily."
            ),
            proTipBn = "প্রো-টিপ: ভিডিওর শেষে এমন কোনো প্রশ্ন করুন যাতে মানুষ কমেন্ট করতে বাধ্য হয়। কমেন্ট বাড়লে ফেসবুক আপনার ভিডিও সবার ফিডে ছড়িয়ে দেবে!",
            proTipEn = "Pro Tip: End every reel with an engaging debate or question. Comment spikes trigger Facebook's viral recommendation wave!",
            category = "Reels Mastery"
        ),
        GrowthGuide(
            id = "yt_shorts_subscribers",
            platform = "YOUTUBE",
            titleBn = "ইউটিউব শর্টস দিয়ে দ্রুত ১,০০০+ সাবস্ক্রাইবার অর্জনের কৌশল",
            titleEn = "Convert Shorts Viewers into Loyal Subscribers Fast",
            subtitleBn = "ভিউয়ারকে সাবস্ক্রাইবারে পরিণত করার নিশ্চিত সাইকোলজি",
            subtitleEn = "Proven psychological conversion tactics for 1,000+ subs",
            readTime = "4 min read",
            stepsBn = listOf(
                "শর্টসের শেষ ২ সেকেন্ডে সাবস্ক্রাইব করার স্পেসিফিক কারণ দিন (Call to Action)।",
                "সাসপেন্স তৈরি করুন—'পার্ট ২ দেখতে সাবস্ক্রাইব করে রাখুন' ট্রিক এখনও সবচেয়ে কার্যকরী।",
                "কমেন্ট বক্সে আপনার চ্যানেলের রিলেটেড বড় ভিডিও লিঙ্ক পিন করে রাখুন।",
                "শর্টসের প্রথম সেকেন্ডেই টেক্সট ওভারলে (Bold Text) দিয়ে সাবজেক্ট বুঝিয়ে দিন।",
                "প্রতিদিন ১টি করে কোয়ালিটি শর্টস টানা ৩০ দিন আপলোড করুন।"
            ),
            stepsEn = listOf(
                "Add a specific Call-To-Action in the final 2 seconds explaining what they gain by subscribing.",
                "Leverage cliffhanger storytelling ('Subscribe for Part 2 resolution')—consistently yields highest conversion.",
                "Pin a comment linking your featured long-form video on related topics.",
                "Use big, bold high-contrast text overlays in the first 0.5s to freeze scrolling thumbs.",
                "Maintain a 30-day streak of 1 high-retention Short per day to trigger algorithm trust."
            ),
            proTipBn = "প্রো-টিপ: শর্টস লুপ (Seamless Loop) করুন যাতে শেষ শব্দ আর প্রথম শব্দ মিলে যায়, দর্শক বুঝতেই পারবে না ভিডিও শেষ হয়েছে!",
            proTipEn = "Pro Tip: Craft seamless audio loops where the last word connects naturally to the first sentence for infinite watch-loops!",
            category = "Shorts Growth"
        ),
        GrowthGuide(
            id = "fb_page_growth_organic",
            platform = "FACEBOOK",
            titleBn = "ফেসবুক পেজে সম্পূর্ণ অর্গানিক উপায়ে আনলিমিটেড ফলোয়ার বাড়ানো",
            titleEn = "100% Organic Facebook Page Follower Scaling",
            subtitleBn = "কোনো টাকা খরচ না করে রিয়েল অডিয়েন্স তৈরির রোডম্যাপ",
            subtitleEn = "Zero-cost roadmap to building real, engaged organic followers",
            readTime = "5 min read",
            stepsBn = listOf(
                "আপনার নিশ (Niche) সম্পর্কিত ৫-১০টি বড় ফেসবুক গ্রুপে অ্যাক্টিভ থাকুন ও তথ্যবহুল পোস্ট দিন।",
                "লাইভ ভিডিও (Facebook Live) করুন—লাইভ ভিডিওর নোটিফিকেশন ফেসবুক সবচেয়ে বেশি ছড়ায়।",
                "ভিজ্যুয়াল ইনফোগ্রাফিক ও কোটস পোস্ট করুন যা মানুষ নিজের টাইমলাইনে শেয়ার করতে পছন্দ করে।",
                "প্রতিটি কমেন্টের রিপ্লাই দিন। অ্যাক্টিভ পেইজকে ফেসবুক অ্যালগরিদম বেশি বুস্ট করে।",
                "অন্যান্য সমগোত্রীয় ক্রিয়েটরদের সাথে কোলাবোরেশন বা ট্যাগ পার্টনারশিপ করুন।"
            ),
            stepsEn = listOf(
                "Be active in 5-10 large community groups in your niche, posting high-value solutions.",
                "Host weekly Facebook Live sessions—live broadcasts receive highest organic notification priority.",
                "Post shareable visual cards, carousel insights, and relatable quotes that compel timeline re-shares.",
                "Reply to comments within the first hour of posting to spike momentum.",
                "Collaborate with peer creators using the Facebook Collabs tag feature to cross-pollinate fans."
            ),
            proTipBn = "প্রো-টিপ: আপনার পেজের 'Invite Friends' এবং পোস্টে যারা রিঅ্যাক্ট দেয় তাদের 'Invite to Follow' নিয়মিত করুন!",
            proTipEn = "Pro Tip: Always click on post reactions and tap 'Invite to Follow'—up to 40% will convert to page followers!",
            category = "Page Scaling"
        ),
        GrowthGuide(
            id = "yt_seo_ctr_secrets",
            platform = "YOUTUBE",
            titleBn = "ইউটিউব থাম্বনেইল ও টাইটেল CTR রহস্য (১০x ভিউ ও সাবস্ক্রাইব)",
            titleEn = "Thumbnail & Title CTR Secrets (10x Views & Subs)",
            subtitleBn = "ক্লিক-থ্রু রেট (CTR) ১০% এর উপরে নেওয়ার প্রমাণিত কৌশল",
            subtitleEn = "Get higher click-through rates and high-ranking search traffic",
            readTime = "4 min read",
            stepsBn = listOf(
                "থাম্বনেইলে ৩-৪ টির বেশি শব্দ লিখবেন না। লেখা বড় ও স্পষ্ট রাখুন।",
                "মুখে তীব্র এক্সপ্রেশন (আশ্চর্য, কৌতূহল বা হাসি) ব্যবহার করুন। চোখ যেন বড় দেখায়।",
                "ব্যাকগ্রাউন্ড এবং টেক্সটের মধ্যে উচ্চ কনট্রাস্ট রাখুন (যেমন কালো ব্যাকগ্রাউন্ডে হলুদ/সাদা লেখা)।",
                "টাইটেলে কৌতূহল ও ইমোশনাল শব্দ (যেমন: 'অবাক করা', 'গোপন তথ্য', 'Never Do This') ব্যবহার করুন।",
                "ডেসক্রিপশনে প্রথম ২০০ অক্ষরে মূল কি-ওয়ার্ড অন্তর্ভুক্ত করুন।"
            ),
            stepsEn = listOf(
                "Limit thumbnail text to 3-4 punchy words. Big, readable typography.",
                "Use high-emotion facial expressions (intense curiosity, surprise) with clear eye contact.",
                "High contrast background colors (e.g. bright yellow text over dark backdrop).",
                "Infuse emotional curiosity gap words in titles ('Secret', 'The Truth About', 'Don't Miss').",
                "Place primary search keywords naturally within the first 200 characters of the description."
            ),
            proTipBn = "প্রো-টিপ: মোবাইলে ছোট প্রিভিউতে থাম্বনেইল স্পষ্ট বোঝা যাচ্ছে কিনা তা আপলোড করার আগেই চেক করে নিন!",
            proTipEn = "Pro Tip: Test your thumbnail at 10% zoom size to ensure it pops on tiny mobile screens!",
            category = "SEO & CTR"
        ),
        GrowthGuide(
            id = "tiktok_1m_roadmap",
            platform = "TIKTOK",
            titleBn = "টিকটকে ১ মিলিয়ন (১০ লাখ) ফলোয়ার পাওয়ার বাস্তব রোডম্যাপ",
            titleEn = "The True Roadmap to 1 Million TikTok Followers (No Fake Bots)",
            subtitleBn = "এক ক্লিকে ফেক বট নয়, অ্যালগরিদম হ্যাক করে আসল মানুষের ফলোয়ার পাওয়ার কৌশল",
            subtitleEn = "Stop falling for fake 1-click scams; scale real organic audiences fast",
            readTime = "4 min read",
            stepsBn = listOf(
                "বাস্তব সত্য: পৃথিবীতে কোনো অ্যাপ নেই যা 'এক ক্লিকে ১০ লাখ রিয়েল ফলোয়ার' বানিয়ে দেয়। যারা বলে তারা অ্যাকাউন্ট ব্যান বা হ্যাক করে ফেলে।",
                "অরিজিনাল FYP ট্রিক: টিকটকে ট্রেন্ডিং সাউন্ড ও ৭-৯ সেকেন্ডের ফাস্ট-কাট ভিডিওতে ওয়াচ টাইম ১৫০% অতিক্রম করালে টিকটক নিজে ভিডিও লাখ লাখ মানুষের কাছে পুশ করে।",
                "লুপ ভিডিও ফর্মুলা (Loop Video): ভিডিওর শেষ বাক্য আর শুরুর বাক্য এমনভাবে মিলিয়ে দিন যাতে দর্শক বারবার ভিডিও দেখতে থাকে।",
                "কন্টিনিউয়াস সিরিজ বানান: '১ম পর্ব', '২য় পর্ব' বানিয়ে দর্শককে আপনার প্রোফাইলে ঢুকতে এবং ফলো করতে বাধ্য করুন।",
                "সোশ্যালবুস্ট এক্সচেঞ্জ ব্যবহার করুন: প্রতিদিন রিয়েল ক্রিয়েটরদের সাথে এক্সচেঞ্জ করে অর্গানিক ইনিশিয়াল বুস্ট নিন।"
            ),
            stepsEn = listOf(
                "Truth Check: No system on earth generates 1M real active followers in 1 click—those are malicious bot scams that shadowban accounts.",
                "Original FYP Engine: Videos between 7-9 seconds with 150%+ retention get auto-recommended to millions on the For You Page.",
                "Seamless Loop Secret: Connect your ending words seamlessly to the video intro to induce infinite auto-replays.",
                "Series Strategy: Multi-part storytelling drives users directly to your profile page to hit the Follow button.",
                "Use SocialBoost Community: Gain organic momentum and initial engagement from real active creators."
            ),
            proTipBn = "প্রো-টিপ: কোনো থার্ড-পার্টি ওয়েবসাইটে আপনার টিকটক পাসওয়ার্ড কখনোই দেবেন না! টিকটকের সেরা ট্রিক হলো দিনে ৩টি করে কনসিস্টেন্ট ট্রেন্ডিং রিলস বা ভিডিও আপলোড করা!",
            proTipEn = "Pro Tip: Never enter your TikTok password on shady follower generator sites. Consistency of 3 high-retention short videos daily is the only real path to 1M!",
            category = "TikTok Mastery"
        )
    )
}
