package com.example.data.content

data class HashtagPack(
    val id: String,
    val titleBn: String,
    val titleEn: String,
    val platform: String, // "FACEBOOK", "YOUTUBE", "BOTH"
    val hashtags: List<String>,
    val category: String,
    val popularityScore: Int
)

data class TitleTemplate(
    val templateBn: String,
    val templateEn: String,
    val platform: String,
    val estimatedCtr: String
)

object ViralToolsData {
    val hashtagPacks = listOf(
        HashtagPack(
            id = "tiktok_fyp_viral",
            titleBn = "টিকটক ১M ভাইরাল FYP প্যাক",
            titleEn = "TikTok 1M Viral FYP Superpack",
            platform = "TIKTOK",
            category = "TikTok FYP",
            popularityScore = 99,
            hashtags = listOf(
                "#fyp", "#foryou", "#foryoupage", "#viral",
                "#trending", "#tiktokbd", "#tiktokbangladesh", "#viralvideo",
                "#1millionaudition", "#blowthisup", "#duet", "#comedy"
            )
        ),
        HashtagPack(
            id = "fb_viral_reels",
            titleBn = "ফেসবুক ভাইরাল রিলস সুপারপ্যাক",
            titleEn = "Facebook Reels Viral Superpack",
            platform = "FACEBOOK",
            category = "Reels",
            popularityScore = 99,
            hashtags = listOf(
                "#fbreels", "#reelsviral", "#facebookreels", "#viralpost",
                "#reelsfb", "#trendingreels", "#fypシ", "#viralreelsfacebook",
                "#explorepage", "#viralvideo", "#fbreelspage", "#growfacebook"
            )
        ),
        HashtagPack(
            id = "yt_shorts_viral",
            titleBn = "ইউটিউব শর্টস ভাইরাল হ্যাশট্যাগ",
            titleEn = "YouTube Shorts Viral Tag Pack",
            platform = "YOUTUBE",
            category = "Shorts",
            popularityScore = 98,
            hashtags = listOf(
                "#shorts", "#youtubeshorts", "#shortsvideo", "#viralshorts",
                "#trendingshorts", "#ytshorts", "#shortsfeed", "#subscribe",
                "#subscribers", "#sub4sub", "#growyoutube", "#creatorhub"
            )
        ),
        HashtagPack(
            id = "bd_trending_pack",
            titleBn = "বাংলাদেশি ট্রেন্ডিং ক্রিয়েটর প্যাক",
            titleEn = "Bangladeshi Trending Creator Pack",
            platform = "BOTH",
            category = "Regional BD",
            popularityScore = 96,
            hashtags = listOf(
                "#bangladesh", "#banglacontent", "#dhakagram", "#banglavlog",
                "#banglanatok", "#banglatrending", "#bdfyp", "#deshicreator",
                "#banglanews", "#banglamusic", "#banglagaming", "#bdtiktok"
            )
        ),
        HashtagPack(
            id = "gaming_superpack",
            titleBn = "গেমিং ও লাইভ স্ট্রিম গ্রোথ প্যাক",
            titleEn = "Gaming & Esports Growth Pack",
            platform = "BOTH",
            category = "Gaming",
            popularityScore = 95,
            hashtags = listOf(
                "#gaming", "#gamer", "#freefire", "#pubgmobile",
                "#gameplay", "#streamer", "#gamingcommunity", "#pcgaming",
                "#highlights", "#esports", "#proplayer", "#gamingreels"
            )
        ),
        HashtagPack(
            id = "tech_tutorial_pack",
            titleBn = "টেক ও টিউটোরিয়াল SEO ট্যাগ প্যাক",
            titleEn = "Tech & How-To High CPM Tags",
            platform = "BOTH",
            category = "Tech",
            popularityScore = 94,
            hashtags = listOf(
                "#techbangla", "#technology", "#androidtips", "#gadgets",
                "#smartphone", "#techtips", "#software", "#tutorial",
                "#tipsandtricks", "#howto", "#review", "#mobiletech"
            )
        ),
        HashtagPack(
            id = "cooking_lifestyle_pack",
            titleBn = "রান্না ও লাইফস্টাইল ভাইরাল প্যাক",
            titleEn = "Food, Cooking & Lifestyle Pack",
            platform = "BOTH",
            category = "Lifestyle",
            popularityScore = 93,
            hashtags = listOf(
                "#cooking", "#foodie", "#banglarecipe", "#streetfood",
                "#deshifood", "#easyrecipes", "#foodvlog", "#delicious",
                "#homemade", "#foodlover", "#villagelife", "#villagefood"
            )
        )
    )

    fun generateViralTitles(topic: String, platform: String): List<Pair<String, String>> {
        val cleanTopic = if (topic.isBlank()) "এই ট্রিকটি" else topic.trim()
        return listOf(
            Pair(
                "$cleanTopic নিয়ে এই গোপন সত্যটি কেউ বলবে না! (১০০% সত্যি)",
                "The Shocking Truth About $cleanTopic Nobody Tells You!"
            ),
            Pair(
                "মাত্র ৩ মিনিটে $cleanTopic করার সহজ উপায়! (নতুন নিয়ম ২০২৬)",
                "How to Master $cleanTopic in 3 Minutes! (New 2026 Secret)"
            ),
            Pair(
                "$cleanTopic করার আগে এই ১টি ভুল কখনোই করবেন না!",
                "NEVER Do This 1 Huge Mistake With $cleanTopic!"
            ),
            Pair(
                "$cleanTopic দিয়ে কীভাবে লাখ লাখ ফলোয়ার পাবেন? (লাইভ প্রুফ)",
                "How $cleanTopic Gets Millions of Followers! (Live Proof)"
            ),
            Pair(
                "আপনি কি $cleanTopic এর এই জাদুকরী ট্রিক জানেন?",
                "Do You Know This Insane $cleanTopic Magic Hack?"
            )
        )
    }

    val thumbnailChecklistItemsBn = listOf(
        "টেক্সট সর্বোচ্চ ৩-৪ টি শব্দে সীমাবদ্ধ রাখা হয়েছে",
        "মুখের অভিব্যক্তি (Expression) বড় ও স্পষ্ট দেখা যাচ্ছে",
        "ব্যাকগ্রাউন্ড এবং লেখার রঙে হাই-কনট্রাস্ট আছে",
        "মোবাইল স্ক্রিনে ছোট করলেও লেখা পড়া যাচ্ছে",
        "টাইটেল এবং থাম্বনেইলে আকর্ষণীয় কিউরিওসিটি গ্যাপ তৈরি করা হয়েছে"
    )

    val thumbnailChecklistItemsEn = listOf(
        "Text is limited to 3-4 powerful words max",
        "Facial expressions are bold, clear and emotive",
        "High contrast exists between background and text",
        "Legible even when scaled down to mobile screen size",
        "Curiosity gap is established between title & image"
    )
}
