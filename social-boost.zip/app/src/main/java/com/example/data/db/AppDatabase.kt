package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CreatorProfile
import com.example.data.model.GrowthChallenge
import com.example.data.model.SavedItem
import com.example.data.model.UserStats

@Database(
    entities = [
        CreatorProfile::class,
        UserStats::class,
        GrowthChallenge::class,
        SavedItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun creatorDao(): CreatorDao
    abstract fun userStatsDao(): UserStatsDao
    abstract fun growthChallengeDao(): GrowthChallengeDao
    abstract fun savedItemDao(): SavedItemDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "social_boost_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
