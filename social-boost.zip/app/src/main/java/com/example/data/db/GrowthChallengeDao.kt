package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.GrowthChallenge
import kotlinx.coroutines.flow.Flow

@Dao
interface GrowthChallengeDao {
    @Query("SELECT * FROM challenges")
    fun getAllChallenges(): Flow<List<GrowthChallenge>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefaultChallenges(challenges: List<GrowthChallenge>)

    @Update
    suspend fun updateChallenge(challenge: GrowthChallenge)

    @Query("UPDATE challenges SET currentCount = currentCount + 1, isCompleted = CASE WHEN currentCount + 1 >= targetCount THEN 1 ELSE 0 END WHERE id = :id AND isClaimed = 0")
    suspend fun incrementChallengeProgress(id: String)

    @Query("UPDATE challenges SET isClaimed = 1 WHERE id = :id")
    suspend fun markAsClaimed(id: String)
}
