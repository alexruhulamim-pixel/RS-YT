package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CreatorProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface CreatorDao {
    @Query("SELECT * FROM creators ORDER BY boostActive DESC, id DESC")
    fun getAllCreators(): Flow<List<CreatorProfile>>

    @Query("SELECT * FROM creators WHERE isUserChannel = 1 ORDER BY id DESC")
    fun getUserCampaigns(): Flow<List<CreatorProfile>>

    @Query("SELECT * FROM creators WHERE platform = :platform ORDER BY boostActive DESC, id DESC")
    fun getCreatorsByPlatform(platform: String): Flow<List<CreatorProfile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCreator(creator: CreatorProfile): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertInitialCreators(creators: List<CreatorProfile>)

    @Update
    suspend fun updateCreator(creator: CreatorProfile)

    @Query("UPDATE creators SET isSupportedByUser = 1 WHERE id = :id")
    suspend fun markAsSupported(id: Long)

    @Query("UPDATE creators SET impressionsDelivered = impressionsDelivered + 1 WHERE boostActive = 1")
    suspend fun incrementBoostImpressions()

    @Query("DELETE FROM creators WHERE id = :id")
    suspend fun deleteCreator(id: Long)
}
