package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.screens.ExchangeScreen
import com.example.ui.screens.GuidesScreen
import com.example.ui.screens.MilestoneScreen
import com.example.ui.screens.RewardsScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.screens.TopGrowthBar
import com.example.ui.theme.CoinGold
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.YouTubeRed
import com.example.ui.viewmodel.GrowthViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GrowthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

data class NavItem(
    val titleBn: String,
    val titleEn: String,
    val icon: ImageVector,
    val tag: String
)

@Composable
fun MainAppScreen(viewModel: GrowthViewModel) {
    val activeScreen by viewModel.activeScreen.collectAsState()
    val userStats by viewModel.userStats.collectAsState()
    val lang = userStats?.language ?: "bn"
    val credits = userStats?.credits ?: 0

    // BackHandler: if on any other tab, pressing back navigates back to Exchange (tab 0)
    BackHandler(enabled = activeScreen != 0) {
        viewModel.setActiveScreen(0)
    }

    val navItems = listOf(
        NavItem("এক্সচেঞ্জ", "Exchange", Icons.Default.Handshake, "nav_exchange"),
        NavItem("AI টুলস", "Tools", Icons.Default.RocketLaunch, "nav_tools"),
        NavItem("ফ্রি কয়েন", "Rewards", Icons.Default.CardGiftcard, "nav_rewards"),
        NavItem("গাইড", "Guides", Icons.Default.MenuBook, "nav_guides"),
        NavItem("মাইলফলক", "Goals", Icons.Default.Timeline, "nav_goals")
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            TopGrowthBar(
                credits = credits,
                language = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                onAddCoins = { amount -> viewModel.claimUnlimitedCoins(amount) }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar")
            ) {
                navItems.forEachIndexed { index, item ->
                    val isSelected = activeScreen == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setActiveScreen(index) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = if (lang == "bn") item.titleBn else item.titleEn,
                                tint = if (isSelected) NeonCyan else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = if (lang == "bn") item.titleBn else item.titleEn,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) NeonCyan else TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NeonCyan,
                            unselectedIconColor = TextMuted,
                            selectedTextColor = NeonCyan,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = DarkSurfaceVariant
                        ),
                        modifier = Modifier.testTag(item.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeScreen) {
                0 -> ExchangeScreen(viewModel = viewModel)
                1 -> ToolsScreen(viewModel = viewModel)
                2 -> RewardsScreen(viewModel = viewModel)
                3 -> GuidesScreen(viewModel = viewModel)
                4 -> MilestoneScreen(viewModel = viewModel)
                else -> ExchangeScreen(viewModel = viewModel)
            }
        }
    }
}
