package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CreatorProfile
import com.example.ui.theme.CoinGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TikTokPink
import com.example.ui.theme.YouTubeRed
import com.example.ui.viewmodel.GrowthViewModel

@Composable
fun ExchangeScreen(
    viewModel: GrowthViewModel,
    modifier: Modifier = Modifier
) {
    val creators by viewModel.allCreators.collectAsState()
    val userCampaigns by viewModel.userCampaigns.collectAsState()
    val userStats by viewModel.userStats.collectAsState()
    val selectedFilter by viewModel.selectedPlatformFilter.collectAsState()
    val showAddDialog by viewModel.showAddCampaignDialog.collectAsState()

    val lang = userStats?.language ?: "bn"
    val credits = userStats?.credits ?: 0

    val filteredList = when (selectedFilter) {
        "YOUTUBE" -> creators.filter { it.platform == "YOUTUBE" }
        "TIKTOK" -> creators.filter { it.platform == "TIKTOK" }
        "FACEBOOK" -> creators.filter { it.platform == "FACEBOOK" }
        "MY_CAMPAIGNS" -> userCampaigns
        else -> creators
    }

    Box(modifier = modifier.fillMaxSize().background(DarkBg)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner
            item {
                HeroBannerCard(
                    language = lang,
                    onPromoteClick = { viewModel.setShowAddCampaignDialog(true) }
                )
            }

            // Filter Tabs Row
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (lang == "bn") "কমিউনিটি চ্যানেল ও পেজসমূহ" else "Spotlight Community Channels",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${filteredList.size} ${if (lang == "bn") "টি ক্রিয়েটর" else "Creators"}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                label = if (lang == "bn") "সবগুলো (${creators.size})" else "All (${creators.size})",
                                isSelected = selectedFilter == "ALL",
                                onClick = { viewModel.setPlatformFilter("ALL") }
                            )
                        }
                        item {
                            FilterChip(
                                label = if (lang == "bn") "ইউটিউব (${creators.count { it.platform == "YOUTUBE" }})" else "YouTube",
                                isSelected = selectedFilter == "YOUTUBE",
                                activeColor = YouTubeRed,
                                onClick = { viewModel.setPlatformFilter("YOUTUBE") }
                            )
                        }
                        item {
                            FilterChip(
                                label = if (lang == "bn") "টিকটক (${creators.count { it.platform == "TIKTOK" }})" else "TikTok",
                                isSelected = selectedFilter == "TIKTOK",
                                activeColor = TikTokPink,
                                onClick = { viewModel.setPlatformFilter("TIKTOK") }
                            )
                        }
                        item {
                            FilterChip(
                                label = if (lang == "bn") "ফেসবুক (${creators.count { it.platform == "FACEBOOK" }})" else "Facebook",
                                isSelected = selectedFilter == "FACEBOOK",
                                activeColor = FacebookBlue,
                                onClick = { viewModel.setPlatformFilter("FACEBOOK") }
                            )
                        }
                        item {
                            FilterChip(
                                label = if (lang == "bn") "আমার বুস্ট (${userCampaigns.size})" else "My Campaigns (${userCampaigns.size})",
                                isSelected = selectedFilter == "MY_CAMPAIGNS",
                                activeColor = NeonCyan,
                                onClick = { viewModel.setPlatformFilter("MY_CAMPAIGNS") }
                            )
                        }
                    }
                }
            }

            // Empty state for My Campaigns
            if (selectedFilter == "MY_CAMPAIGNS" && userCampaigns.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = if (lang == "bn") "আপনি এখনও কোনো চ্যানেল বা পেজ বুস্ট করেননি" else "No Active Campaigns Yet",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (lang == "bn")
                                    "নিচের + বাটনে চাপ দিয়ে আপনার ফেসবুক বা ইউটিউব লিঙ্ক যুক্ত করুন এবং আনলিমিটেড ফলোয়ার পান।"
                                else
                                    "Tap the + button to launch your free promotion campaign and get real followers.",
                                color = TextSecondary,
                                fontSize = 13.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Creators List
            items(filteredList, key = { it.id }) { creator ->
                CreatorProfileCard(
                    creator = creator,
                    language = lang,
                    onVisitAndSupport = { viewModel.visitAndSupportCreator(it) },
                    onDelete = if (creator.isUserChannel) {
                        { viewModel.deleteCampaign(creator.id) }
                    } else null
                )
            }
        }

        // Floating Action Button to Add Profile
        FloatingActionButton(
            onClick = { viewModel.setShowAddCampaignDialog(true) },
            containerColor = YouTubeRed,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 24.dp, end = 20.dp)
                .testTag("fab_add_campaign")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Campaign")
                Text(
                    text = if (lang == "bn") "বুস্ট করুন" else "Boost Link",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }

    // Add Campaign Modal Dialog
    if (showAddDialog) {
        AddCampaignDialog(
            userCredits = credits,
            language = lang,
            onDismiss = { viewModel.setShowAddCampaignDialog(false) },
            onSubmit = { platform, name, url, category, allocatedCoins, description ->
                viewModel.createCampaign(
                    platform = platform,
                    name = name,
                    url = url,
                    category = category,
                    allocatedCoins = allocatedCoins,
                    description = description
                ) { success, msg ->
                    // Handled inside ViewModel
                }
            }
        )
    }
}

@Composable
fun FilterChip(
    label: String,
    isSelected: Boolean,
    activeColor: Color = NeonCyan,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() },
        color = if (isSelected) activeColor else DarkSurfaceVariant,
        shape = RoundedCornerShape(20.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.Black else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}
