package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.CreatorProfile
import com.example.data.model.GrowthChallenge
import com.example.data.model.SavedItem
import com.example.data.model.UserStats
import com.example.data.repository.GrowthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GrowthViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GrowthRepository(AppDatabase.getDatabase(application))

    val userStats: StateFlow<UserStats?> = repository.userStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allCreators: StateFlow<List<CreatorProfile>> = repository.allCreators
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userCampaigns: StateFlow<List<CreatorProfile>> = repository.userCampaigns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allChallenges: StateFlow<List<GrowthChallenge>> = repository.allChallenges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedItems: StateFlow<List<SavedItem>> = repository.savedItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedPlatformFilter = MutableStateFlow("ALL") // "ALL", "YOUTUBE", "FACEBOOK"
    val selectedPlatformFilter: StateFlow<String> = _selectedPlatformFilter.asStateFlow()

    private val _activeScreen = MutableStateFlow(0) // 0: Exchange, 1: Tools, 2: Rewards, 3: Guides, 4: Milestones
    val activeScreen: StateFlow<Int> = _activeScreen.asStateFlow()

    private val _isSpinning = MutableStateFlow(false)
    val isSpinning: StateFlow<Boolean> = _isSpinning.asStateFlow()

    private val _lastSpinResult = MutableStateFlow<Int?>(null)
    val lastSpinResult: StateFlow<Int?> = _lastSpinResult.asStateFlow()

    private val _showAddCampaignDialog = MutableStateFlow(false)
    val showAddCampaignDialog: StateFlow<Boolean> = _showAddCampaignDialog.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeSeedDataIfNeeded()
        }
    }

    fun setPlatformFilter(filter: String) {
        _selectedPlatformFilter.value = filter
    }

    fun setActiveScreen(screenIndex: Int) {
        _activeScreen.value = screenIndex
    }

    fun setShowAddCampaignDialog(show: Boolean) {
        _showAddCampaignDialog.value = show
    }

    fun visitAndSupportCreator(creator: CreatorProfile) {
        viewModelScope.launch {
            try {
                val rawUrl = creator.handleOrUrl.trim()
                val targetUri = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) {
                    Uri.parse(rawUrl)
                } else if (creator.platform == "YOUTUBE") {
                    Uri.parse("https://www.youtube.com/$rawUrl")
                } else if (creator.platform == "TIKTOK") {
                    Uri.parse(if (rawUrl.startsWith("@")) "https://www.tiktok.com/$rawUrl" else "https://www.tiktok.com/@$rawUrl")
                } else {
                    Uri.parse("https://www.facebook.com/$rawUrl")
                }

                val intent = Intent(Intent.ACTION_VIEW, targetUri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(intent)
            } catch (e: Exception) {
                // If specific app not found or format error, fallback safely
            }

            val earned = repository.supportCreator(creator)
            val lang = userStats.value?.language ?: "bn"
            val msg = if (lang == "bn") {
                "অভিনন্দন! আপনি +$earned টি ফ্রি গ্রোথ কয়েন পেয়েছেন!"
            } else {
                "Awesome! You received +$earned free growth credits!"
            }
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun createCampaign(
        platform: String,
        name: String,
        url: String,
        category: String,
        allocatedCoins: Int,
        description: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val success = repository.createOrBoostUserCampaign(
                platform = platform,
                name = name,
                url = url,
                category = category,
                allocatedCoins = allocatedCoins,
                description = description
            )
            val lang = userStats.value?.language ?: "bn"
            if (success) {
                _showAddCampaignDialog.value = false
                val msg = if (lang == "bn") {
                    "আপনার চ্যানেল সফলভাবে বুস্ট লিস্টে যুক্ত হয়েছে! কমিউনিটি থেকে রিয়েল ফলোয়ার ও সাবস্ক্রাইবার আসা শুরু হয়েছে।"
                } else {
                    "Your channel was added to the Spotlight showcase! Real members are visiting now."
                }
                onResult(true, msg)
            } else {
                val msg = if (lang == "bn") {
                    "পর্যাপ্ত কয়েন নেই! ফ্রি কয়েন পেতে টাস্ক সম্পন্ন করুন বা লাকি হুইল ঘুরান।"
                } else {
                    "Not enough credits! Complete free tasks or spin the lucky wheel to get more."
                }
                onResult(false, msg)
            }
        }
    }

    fun claimDailyBonus(onClaimed: (Boolean, Int) -> Unit) {
        viewModelScope.launch {
            val (success, amount) = repository.claimDailyReward()
            onClaimed(success, amount)
        }
    }

    fun spinWheel() {
        if (_isSpinning.value) return
        viewModelScope.launch {
            _isSpinning.value = true
            _lastSpinResult.value = null
            kotlinx.coroutines.delay(1800) // Realistic spin wheel suspense
            val won = repository.spinLuckyWheel()
            _lastSpinResult.value = won
            _isSpinning.value = false
        }
    }

    fun claimChallenge(challenge: GrowthChallenge) {
        viewModelScope.launch {
            val success = repository.claimChallengeReward(challenge)
            if (success) {
                val lang = userStats.value?.language ?: "bn"
                val msg = if (lang == "bn") {
                    "+${challenge.rewardCredits} কয়েন আপনার অ্যাকাউন্টে জমা হয়েছে!"
                } else {
                    "+${challenge.rewardCredits} credits added to your wallet!"
                }
                Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            repository.toggleLanguage()
        }
    }

    fun recordAction(actionType: String) {
        viewModelScope.launch {
            repository.recordToolAction(actionType)
        }
    }

    fun saveItem(type: String, platform: String, category: String, content: String) {
        viewModelScope.launch {
            repository.saveItem(type, platform, category, content)
            val lang = userStats.value?.language ?: "bn"
            val msg = if (lang == "bn") "বুকমার্কে সেভ করা হয়েছে!" else "Saved to bookmarks!"
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteSavedItem(id: Long) {
        viewModelScope.launch {
            repository.deleteSavedItem(id)
        }
    }

    fun deleteCampaign(id: Long) {
        viewModelScope.launch {
            repository.deleteCampaign(id)
        }
    }

    fun claimUnlimitedCoins(amount: Int = 10000) {
        viewModelScope.launch {
            repository.addUnlimitedCoins(amount)
            val lang = userStats.value?.language ?: "bn"
            val msg = if (lang == "bn") {
                "🎉 সফল! আপনার অ্যাকাউন্টে +$amount ফ্রি কয়েন যোগ করা হয়েছে!"
            } else {
                "🎉 Success! +$amount free coins added to your wallet!"
            }
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }
}
