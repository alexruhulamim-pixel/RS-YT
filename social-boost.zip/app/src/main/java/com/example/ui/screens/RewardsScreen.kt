package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GrowthChallenge
import com.example.ui.theme.CoinGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.YouTubeRed
import com.example.ui.viewmodel.GrowthViewModel
import java.time.LocalDate

@Composable
fun RewardsScreen(
    viewModel: GrowthViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userStats by viewModel.userStats.collectAsState()
    val challenges by viewModel.allChallenges.collectAsState()
    val isSpinning by viewModel.isSpinning.collectAsState()
    val lastSpinResult by viewModel.lastSpinResult.collectAsState()

    val lang = userStats?.language ?: "bn"
    val credits = userStats?.credits ?: 0
    val todayEpoch = LocalDate.now().toEpochDay()
    val isDailyClaimed = (userStats?.lastDailyClaimEpochDay ?: 0) >= todayEpoch

    // Continuous spin wheel animation when spinning
    val infiniteTransition = rememberInfiniteTransition(label = "spin")
    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = CoinGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (lang == "bn") "আনলিমিটেড ফ্রি কয়েন ও রিওয়ার্ড হাব" else "Unlimited Free Credits Center",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = if (lang == "bn")
                        "টাস্ক সম্পন্ন করুন, লাকি হুইল ঘুরান এবং আনলিমিটেড কয়েন সংগ্রহ করে আপনার চ্যানেল বুস্ট করুন।"
                    else
                        "Earn unlimited credits daily through tasks, lucky spins, and bonuses to scale your channel.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // UNLIMITED COINS FAUCET (INSTANT FREE COINS)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, CoinGold)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = CoinGold.copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.MonetizationOn,
                                        contentDescription = null,
                                        tint = CoinGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = if (lang == "bn") "⚡ আনলিমিটেড কয়েন জেনারেটর" else "⚡ Unlimited Coins Faucet",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (lang == "bn") "যতখুশি কয়েন নিন সম্পূর্ণ ফ্রিতে" else "Claim infinite coins anytime",
                                    color = CoinGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreen.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (lang == "bn") "আনলিমিটেড" else "Unlimited",
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // 4 Instant Claim Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.claimUnlimitedCoins(1000) },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text(
                                text = "+১,০০০",
                                color = CoinGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.claimUnlimitedCoins(5000) },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text(
                                text = "+৫,০০০",
                                color = CoinGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.claimUnlimitedCoins(10000) },
                            colors = ButtonDefaults.buttonColors(containerColor = CoinGold),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.2f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text(
                                text = "+১০,০০০",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Daily Bonus Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = CoinGold.copy(alpha = 0.2f),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CardGiftcard,
                                    contentDescription = null,
                                    tint = CoinGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = if (lang == "bn") "দৈনিক ফ্রি বোনাস (+১৫০ কয়েন)" else "Daily Free Reward (+150)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (isDailyClaimed) {
                                    if (lang == "bn") "আজকের বোনাস নেওয়া হয়েছে (আগামীকাল আবার আসুন)" else "Claimed today. Come back tomorrow!"
                                } else {
                                    if (lang == "bn") "আজকের ফ্রি কয়েন এখনই ক্লেইম করুন!" else "Tap to claim today's bonus now!"
                                },
                                color = if (isDailyClaimed) TextMuted else NeonCyan,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.claimDailyBonus { success, amount ->
                                if (success) {
                                    Toast.makeText(
                                        context,
                                        if (lang == "bn") "+$amount টি দৈনিক কয়েন পেয়েছেন!" else "+$amount daily credits claimed!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        if (lang == "bn") "আজকের বোনাস ইতোমধ্যে নেওয়া হয়েছে!" else "Already claimed today!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        },
                        enabled = !isDailyClaimed,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CoinGold,
                            disabledContainerColor = DarkSurfaceVariant
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("claim_daily_bonus_btn")
                    ) {
                        Text(
                            text = if (isDailyClaimed) (if (lang == "bn") "নেওয়া হয়েছে" else "Claimed") else (if (lang == "bn") "ক্লেইম" else "Claim"),
                            color = if (isDailyClaimed) TextMuted else Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Lucky Spin Wheel Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Whatshot, contentDescription = null, tint = YouTubeRed)
                            Text(
                                text = if (lang == "bn") "লাকি স্পিন হুইল (আনলিমিটেড)" else "Lucky Spin Wheel (Unlimited)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreen.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (lang == "bn") "১০০% ফ্রি" else "100% Free",
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Visual Spin Wheel
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.sweepGradient(
                                    listOf(
                                        YouTubeRed,
                                        CoinGold,
                                        NeonCyan,
                                        ElectricPurple,
                                        SuccessGreen,
                                        YouTubeRed
                                    )
                                )
                            )
                            .border(4.dp, DarkSurface, CircleShape)
                            .rotate(if (isSpinning) spinAngle else 0f),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = DarkSurface,
                            modifier = Modifier.size(60.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = CoinGold,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }

                    // Result or CTA
                    if (lastSpinResult != null && !isSpinning) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SuccessGreen.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen)
                        ) {
                            Text(
                                text = if (lang == "bn") "🎉 দারুণ! আপনি +$lastSpinResult ফ্রি কয়েন জিতেছেন!" else "🎉 Congrats! You won +$lastSpinResult Free Credits!",
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }

                    Button(
                        onClick = { viewModel.spinWheel() },
                        enabled = !isSpinning,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("spin_wheel_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Autorenew,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier
                                .size(18.dp)
                                .rotate(if (isSpinning) spinAngle else 0f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSpinning) {
                                if (lang == "bn") "ঘুরছে..." else "Spinning..."
                            } else {
                                if (lang == "bn") "স্পিন ঘুরান ও ফ্রি কয়েন জিতুন!" else "Spin Wheel & Win Coins!"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Creator Quests / Challenges
        item {
            Text(
                text = if (lang == "bn") "দৈনিক ক্রিয়েটর কোয়েস্ট (টাস্ক পূরণ করে ফ্রি কয়েন)" else "Daily Creator Quests",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(challenges, key = { it.id }) { challenge ->
            ChallengeItemCard(
                challenge = challenge,
                language = lang,
                onClaim = { viewModel.claimChallenge(challenge) }
            )
        }
    }
}

@Composable
fun ChallengeItemCard(
    challenge: GrowthChallenge,
    language: String,
    onClaim: () -> Unit
) {
    val progress = (challenge.currentCount.toFloat() / challenge.targetCount.toFloat()).coerceIn(0f, 1f)
    val isCompleted = challenge.currentCount >= challenge.targetCount

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (language == "bn") challenge.titleBn else challenge.titleEn,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = if (language == "bn") challenge.descBn else challenge.descEn,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CoinGold.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "+${challenge.rewardCredits} কয়েন",
                        color = CoinGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Progress Bar & Claim Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (isCompleted) SuccessGreen else NeonCyan,
                        trackColor = DarkSurfaceVariant
                    )
                    Text(
                        text = "${challenge.currentCount}/${challenge.targetCount}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = onClaim,
                    enabled = isCompleted && !challenge.isClaimed,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SuccessGreen,
                        disabledContainerColor = DarkSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("claim_quest_${challenge.id}")
                ) {
                    Text(
                        text = if (challenge.isClaimed) {
                            if (language == "bn") "ক্লেইমড" else "Claimed"
                        } else if (isCompleted) {
                            if (language == "bn") "ক্লেইম" else "Claim"
                        } else {
                            if (language == "bn") "চলমান" else "In Progress"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted && !challenge.isClaimed) Color.White else TextMuted
                    )
                }
            }
        }
    }
}
