package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CoinGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TikTokPink
import com.example.ui.theme.YouTubeRed
import com.example.ui.viewmodel.GrowthViewModel

@Composable
fun MilestoneScreen(
    viewModel: GrowthViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userStats by viewModel.userStats.collectAsState()
    val savedItems by viewModel.savedItems.collectAsState()
    val lang = userStats?.language ?: "bn"

    var currentYtSubs by remember { mutableFloatStateOf(250f) }
    var currentFbFollowers by remember { mutableFloatStateOf(800f) }
    var currentTikTokFollowers by remember { mutableFloatStateOf(1200f) }

    fun copyToClipboard(text: String, label: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Copied Text", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, label, Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (lang == "bn") "মনিটাইজেশন ও মাইলফলক ট্র্যাকার" else "Monetization & Milestone Tracker",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = if (lang == "bn")
                        "ইউটিউব পার্টনার প্রোগ্রাম ও ফেসবুক পেজ মনিটাইজেশনের শর্ত পূরণের অগ্রগতি পর্যবেক্ষণ করুন"
                    else
                        "Track your journey to YouTube Partner Program and Facebook monetization",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // YouTube Monetization Goal
        item {
            val ytProgress = (currentYtSubs / 1000f).coerceIn(0f, 1f)
            val ytSubsNeeded = (1000 - currentYtSubs.toInt()).coerceAtLeast(0)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, YouTubeRed.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = YouTubeRed.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "YouTube Partner Program",
                                    color = YouTubeRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = "${(ytProgress * 100).toInt()}% পূরণ",
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = if (lang == "bn")
                            "টার্গেট: ১,০০০ সাবস্ক্রাইবার (আর প্রয়োজন: $ytSubsNeeded জন)"
                        else
                            "Target: 1,000 Subscribers (Remaining: $ytSubsNeeded)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    LinearProgressIndicator(
                        progress = { ytProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = YouTubeRed,
                        trackColor = DarkSurfaceVariant
                    )

                    Column {
                        Text(
                            text = if (lang == "bn")
                                "বর্তমান সাবস্ক্রাইবার সংখ্যা অ্যাডজাস্ট করুন: ${currentYtSubs.toInt()}"
                            else
                                "Current subscriber count: ${currentYtSubs.toInt()}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Slider(
                            value = currentYtSubs,
                            onValueChange = { currentYtSubs = it },
                            valueRange = 0f..1000f,
                            colors = SliderDefaults.colors(
                                thumbColor = YouTubeRed,
                                activeTrackColor = YouTubeRed,
                                inactiveTrackColor = DarkSurfaceVariant
                            )
                        )
                    }

                    // Estimated Daily projection
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (lang == "bn")
                                "💡 প্রোজেকশন: সোশ্যালবুস্টে প্রতিদিন ১০ জন করে নতুন সাবস্ক্রাইবার যুক্ত হলে আর মাত্র ${(ytSubsNeeded / 10).coerceAtLeast(1)} দিনের মধ্যে মনিটাইজেশন আনলক হবে!"
                            else
                                "💡 Projection: With 10 daily community supporters, reach 1,000 subscribers in just ${(ytSubsNeeded / 10).coerceAtLeast(1)} days!",
                            color = CoinGold,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        // Facebook Monetization Goal
        item {
            val fbProgress = (currentFbFollowers / 5000f).coerceIn(0f, 1f)
            val fbFollowersNeeded = (5000 - currentFbFollowers.toInt()).coerceAtLeast(0)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, FacebookBlue.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = FacebookBlue.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Facebook In-Stream Ads",
                                color = FacebookBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "${(fbProgress * 100).toInt()}% পূরণ",
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = if (lang == "bn")
                            "টার্গেট: ৫,০০০ ফলোয়ার (আর প্রয়োজন: $fbFollowersNeeded জন)"
                        else
                            "Target: 5,000 Followers (Remaining: $fbFollowersNeeded)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    LinearProgressIndicator(
                        progress = { fbProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = FacebookBlue,
                        trackColor = DarkSurfaceVariant
                    )

                    Column {
                        Text(
                            text = if (lang == "bn")
                                "বর্তমান ফলোয়ার সংখ্যা অ্যাডজাস্ট করুন: ${currentFbFollowers.toInt()}"
                            else
                                "Current followers count: ${currentFbFollowers.toInt()}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Slider(
                            value = currentFbFollowers,
                            onValueChange = { currentFbFollowers = it },
                            valueRange = 0f..5000f,
                            colors = SliderDefaults.colors(
                                thumbColor = FacebookBlue,
                                activeTrackColor = FacebookBlue,
                                inactiveTrackColor = DarkSurfaceVariant
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (lang == "bn")
                                "💡 প্রোজেকশন: সোশ্যালবুস্টের ভাইরাল রিলস ট্যাগ ও কমিউনিটি বুস্ট দিয়ে আর ${(fbFollowersNeeded / 25).coerceAtLeast(1)} দিনের মধ্যে পেজ মনিটাইজেশনের জন্য প্রস্তুত হবে!"
                            else
                                "💡 Projection: With viral Reels tags and spotlight boost, hit 5,000 followers in ${(fbFollowersNeeded / 25).coerceAtLeast(1)} days!",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        // TikTok Creator Rewards & 1M Goal
        item {
            val tkProgress = (currentTikTokFollowers / 10000f).coerceIn(0f, 1f)
            val tkFollowersNeeded = (10000 - currentTikTokFollowers.toInt()).coerceAtLeast(0)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TikTokPink.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TikTokPink.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "TikTok Creator Rewards (10K+)",
                                color = TikTokPink,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "${(tkProgress * 100).toInt()}% পূরণ",
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = if (lang == "bn")
                            "টার্গেট: ১০,০০০ ফলোয়ার (১M এর ১ম ধাপ, আর প্রয়োজন: $tkFollowersNeeded জন)"
                        else
                            "Target: 10,000 Followers (1st Step to 1M, Remaining: $tkFollowersNeeded)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    LinearProgressIndicator(
                        progress = { tkProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = TikTokPink,
                        trackColor = DarkSurfaceVariant
                    )

                    Column {
                        Text(
                            text = if (lang == "bn")
                                "বর্তমান টিকটক ফলোয়ার সংখ্যা: ${currentTikTokFollowers.toInt()}"
                            else
                                "Current TikTok followers: ${currentTikTokFollowers.toInt()}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Slider(
                            value = currentTikTokFollowers,
                            onValueChange = { currentTikTokFollowers = it },
                            valueRange = 0f..10000f,
                            colors = SliderDefaults.colors(
                                thumbColor = TikTokPink,
                                activeTrackColor = TikTokPink,
                                inactiveTrackColor = DarkSurfaceVariant
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (lang == "bn")
                                "🔥 ১ মিলিয়ন (১০ লাখ) সত্য: 'এক ক্লিকে ১M ফলোয়ার' কোনো সত্যিকারের জিনিস নয়—কিন্তু সোশ্যালবুস্টের FYP হ্যাশট্যাগ ও ডেইলি কমিউনিটি বুস্ট দিয়ে আপনি দ্রুত ১০K পেরিয়ে আসল ১ মিলিয়নের পথে এগিয়ে যাবেন!"
                            else
                                "🔥 1M Reality: 1-click 1M followers is a myth, but with SocialBoost's FYP superpack and daily community exchange, scaling to 10K and real 1M is completely achievable!",
                            color = CoinGold,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        // Saved Bookmarks Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (lang == "bn") "সংরক্ষিত টাইটেল ও হ্যাশট্যাগ (${savedItems.size})" else "Saved Bookmarks (${savedItems.size})",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (savedItems.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (lang == "bn")
                            "এখনও কোনো টাইটেল বা ট্যাগ বুকমার্ক করা হয়নি। AI টুলস থেকে পছন্দের জিনিস সেভ করে রাখুন।"
                        else
                            "No bookmarks yet. Save viral titles or hashtags from the AI Tools tab.",
                        color = TextMuted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }

        items(savedItems, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.type,
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.content,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Row {
                        IconButton(
                            onClick = {
                                copyToClipboard(
                                    item.content,
                                    if (lang == "bn") "কপি করা হয়েছে!" else "Copied!"
                                )
                            }
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { viewModel.deleteSavedItem(item.id) }
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = YouTubeRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}
