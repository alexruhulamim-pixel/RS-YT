package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.YoutubeSearchedFor
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.CreatorProfile
import com.example.ui.theme.CoinGold
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokPink
import com.example.ui.theme.YouTubeRed

@Composable
fun TopGrowthBar(
    credits: Int,
    language: String,
    onToggleLanguage: () -> Unit,
    onAddCoins: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showCoinVaultDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = DarkSurface,
        tonalElevation = 6.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Branding
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(YouTubeRed, FacebookBlue)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = "SocialBoost Logo",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "SocialBoost",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (language == "bn") "ফলোয়ার ও সাবস্ক্রাইবার হাব" else "Creator Growth Hub",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            // Right Actions: Language Switch + Coin Balance
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Language toggle button
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier
                        .clickable { onToggleLanguage() }
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_language_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (language == "bn") "🇧🇩 বাংলা" else "🇬🇧 EN",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Coin Balance Chip (Tap to get unlimited coins)
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = DarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .clickable { showCoinVaultDialog = true }
                        .testTag("coin_balance_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Credits",
                            tint = CoinGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "$credits",
                            color = CoinGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = CircleShape,
                            color = CoinGold.copy(alpha = 0.2f),
                            modifier = Modifier.size(16.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add Coins",
                                    tint = CoinGold,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCoinVaultDialog) {
        UnlimitedCoinsDialog(
            currentCoins = credits,
            language = language,
            onDismiss = { showCoinVaultDialog = false },
            onClaimCoins = { amount ->
                onAddCoins(amount)
            }
        )
    }
}

@Composable
fun HeroBannerCard(
    language: String,
    onPromoteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column {
            // Visual Image Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.social_growth_banner_1791801724178),
                    contentDescription = "Growth Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
                // Gradient scrim overlay
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, DarkSurfaceVariant.copy(alpha = 0.95f))
                            )
                        )
                )
            }

            // Banner Copy & CTA
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (language == "bn") "১০০% ফ্রি ও অর্গানিক গ্রোথ কমিউনিটি" else "100% Free Organic Creator Network",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = if (language == "bn")
                        "আপনার ইউটিউব চ্যানেল ও ফেসবুক পেজে আনলিমিটেড ফলোয়ার ও সাবস্ক্রাইবার নিন!"
                    else
                        "Boost your Facebook followers & YouTube subscribers with real creators!",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 22.sp
                )

                Text(
                    text = if (language == "bn")
                        "কমিউনিটির অন্যান্য ক্রিয়েটরদের সাপোর্ট করে ফ্রি কয়েন অর্জন করুন এবং আপনার নিজের প্রোফাইল টপ স্পটলাইটে বুস্ট করুন।"
                    else
                        "Support other creators to earn unlimited free credits, then promote your own channel in the spotlight feed.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onPromoteClick,
                    colors = ButtonDefaults.buttonColors(containerColor = YouTubeRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("promote_now_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == "bn") "আমার চ্যানেল/পেজ বুস্ট করুন (ফ্রি)" else "Promote My Channel/Page (Free)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun CreatorProfileCard(
    creator: CreatorProfile,
    language: String,
    onVisitAndSupport: (CreatorProfile) -> Unit,
    onDelete: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isYouTube = creator.platform == "YOUTUBE"
    val isTikTok = creator.platform == "TIKTOK"
    val platformColor = if (isYouTube) YouTubeRed else if (isTikTok) TikTokPink else FacebookBlue
    val platformName = if (isYouTube) "YouTube" else if (isTikTok) "TikTok" else "Facebook"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = if (creator.boostActive) 1.5.dp else 1.dp,
                color = if (creator.boostActive) platformColor.copy(alpha = 0.6f) else DarkBorder,
                shape = RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Platform Tag + Badge + Stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Platform Pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = platformColor.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = platformName,
                                color = platformColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Category Pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = creator.category,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    if (creator.boostActive) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = NeonCyan.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (language == "bn") "বুস্ট অ্যাক্টিভ" else "Spotlight",
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Reward Coin Pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CoinGold.copy(alpha = 0.15f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            tint = CoinGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "+${creator.rewardCredits}",
                            color = CoinGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Channel Title & Count
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = creator.channelOrPageName,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (isYouTube)
                            "${creator.currentSubscribersOrFollowers} ${if (language == "bn") "সাবস্ক্রাইবার" else "Subscribers"}"
                        else
                            "${creator.currentSubscribersOrFollowers} ${if (language == "bn") "ফলোয়ার" else "Followers"}",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }

                if (creator.isUserChannel && onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(
                            text = if (language == "bn") "মুছুন" else "Remove",
                            color = YouTubeRed,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Description
            Text(
                text = creator.description,
                color = TextSecondary,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            // Campaign Delivered Stats if User Channel
            if (creator.isUserChannel) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${creator.impressionsDelivered}",
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (language == "bn") "ইমপ্রেশন" else "Impressions",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${creator.followsOrSubsDelivered}",
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (isYouTube)
                                (if (language == "bn") "সাবস্ক্রাইব প্রাপ্ত" else "Subscribers Gained")
                            else
                                (if (language == "bn") "ফলোয়ার প্রাপ্ত" else "Followers Gained"),
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Visit & Support Action Button
            Button(
                onClick = { onVisitAndSupport(creator) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (creator.isSupportedByUser) SuccessGreen else platformColor
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("support_creator_${creator.id}")
            ) {
                Icon(
                    imageVector = if (creator.isSupportedByUser) Icons.Default.Check else Icons.Default.OpenInNew,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (creator.isSupportedByUser) {
                        if (language == "bn") "ভিজিট ও সাপোর্ট সম্পন্ন (+কয়েন প্রাপ্ত)" else "Supported & Credits Claimed"
                    } else {
                        if (isYouTube) {
                            if (language == "bn") "চ্যানেলে যান ও সাবস্ক্রাইব করুন (+${creator.rewardCredits})" else "Visit Channel & Subscribe (+${creator.rewardCredits})"
                        } else if (isTikTok) {
                            if (language == "bn") "টিকটক প্রোফাইলে যান ও ফলো দিন (+${creator.rewardCredits})" else "Visit TikTok & Follow (+${creator.rewardCredits})"
                        } else {
                            if (language == "bn") "পেজে যান ও ফলো দিন (+${creator.rewardCredits})" else "Visit Page & Follow (+${creator.rewardCredits})"
                        }
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCampaignDialog(
    userCredits: Int,
    language: String,
    onDismiss: () -> Unit,
    onSubmit: (platform: String, name: String, url: String, category: String, allocatedCoins: Int, description: String) -> Unit
) {
    var selectedPlatform by remember { mutableStateOf("YOUTUBE") }
    var channelName by remember { mutableStateOf("") }
    var channelUrl by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tech") }
    var selectedCoins by remember { mutableStateOf(100) }
    var description by remember { mutableStateOf("") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    val categories = listOf("Tech", "Gaming", "Vlog", "Comedy", "Education", "Islamic", "Cooking", "Lifestyle", "Music")
    val coinOptions = listOf(50, 100, 200, 500)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == "bn") "আপনার প্রোফাইল বুস্ট করুন" else "Promote Your Profile",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CoinGold.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "$userCredits ${if (language == "bn") "কয়েন আছে" else "Coins"}",
                            color = CoinGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Platform Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedPlatform = "YOUTUBE" },
                        color = if (selectedPlatform == "YOUTUBE") YouTubeRed else DarkSurfaceVariant
                    ) {
                        Text(
                            text = "YouTube",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 10.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedPlatform = "TIKTOK" },
                        color = if (selectedPlatform == "TIKTOK") TikTokPink else DarkSurfaceVariant
                    ) {
                        Text(
                            text = "TikTok",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 10.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedPlatform = "FACEBOOK" },
                        color = if (selectedPlatform == "FACEBOOK") FacebookBlue else DarkSurfaceVariant
                    ) {
                        Text(
                            text = "Facebook",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 10.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                // Channel Name input
                OutlinedTextField(
                    value = channelName,
                    onValueChange = { channelName = it },
                    label = {
                        Text(
                            when (selectedPlatform) {
                                "YOUTUBE" -> if (language == "bn") "ইউটিউব চ্যানেলের নাম" else "YouTube Channel Name"
                                "TIKTOK" -> if (language == "bn") "টিকটক ইউজারনেম / আইডি" else "TikTok Username"
                                else -> if (language == "bn") "ফেসবুক পেজ/প্রোফাইলের নাম" else "Facebook Page Name"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_channel_name"),
                    singleLine = true
                )

                // Channel URL input
                OutlinedTextField(
                    value = channelUrl,
                    onValueChange = { channelUrl = it },
                    label = {
                        Text(
                            when (selectedPlatform) {
                                "YOUTUBE" -> if (language == "bn") "চ্যানেল লিঙ্ক বা হ্যান্ডেল (যেমন: @yourchannel)" else "Channel Link or @handle"
                                "TIKTOK" -> if (language == "bn") "টিকটক প্রোফাইল লিঙ্ক বা @username" else "TikTok Profile URL or @username"
                                else -> if (language == "bn") "ফেসবুক পেজ বা প্রোফাইল লিঙ্ক" else "Facebook Page or Profile URL"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_channel_url"),
                    singleLine = true
                )

                // Category selector
                ExposedDropdownMenuBox(
                    expanded = categoryDropdownExpanded,
                    onExpandedChange = { categoryDropdownExpanded = !categoryDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (language == "bn") "ক্যাটাগরি" else "Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Coin budget selector
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (language == "bn") "বুস্ট বাজেট নির্বাচন করুন:" else "Select Boost Budget:",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        coinOptions.forEach { coins ->
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedCoins = coins },
                                color = if (selectedCoins == coins) CoinGold else DarkSurfaceVariant
                            ) {
                                Text(
                                    text = "$coins",
                                    color = if (selectedCoins == coins) Color.Black else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }

                // Submit Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (language == "bn") "বাতিল" else "Cancel")
                    }

                    Button(
                        onClick = {
                            if (channelName.isNotBlank() && channelUrl.isNotBlank()) {
                                onSubmit(
                                    selectedPlatform,
                                    channelName.trim(),
                                    channelUrl.trim(),
                                    selectedCategory,
                                    selectedCoins,
                                    description.trim()
                                )
                            }
                        },
                        enabled = channelName.isNotBlank() && channelUrl.isNotBlank() && userCredits >= selectedCoins,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_boost_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedPlatform == "YOUTUBE") YouTubeRed else FacebookBlue
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (language == "bn") "বুস্ট শুরু করুন" else "Launch Boost",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun UnlimitedCoinsDialog(
    currentCoins: Int,
    language: String,
    onDismiss: () -> Unit,
    onClaimCoins: (Int) -> Unit
) {
    val coinPacks = listOf(
        Pair(1000, if (language == "bn") "ছোট প্যাক" else "Starter Pack"),
        Pair(5000, if (language == "bn") "মেগা প্যাক" else "Mega Pack"),
        Pair(10000, if (language == "bn") "আল্ট্রা বুস্ট" else "Ultra Boost"),
        Pair(50000, if (language == "bn") "আনলিমিটেড VIP" else "Unlimited VIP")
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CoinGold.copy(alpha = 0.8f))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = CoinGold.copy(alpha = 0.2f),
                    modifier = Modifier.size(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            tint = CoinGold,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Text(
                    text = if (language == "bn") "⚡ আনলিমিটেড ফ্রি কয়েন ভল্ট" else "⚡ Infinite Free Coins Vault",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Text(
                    text = if (language == "bn")
                        "কোনো টাকা লাগবে না! যতখুশি কয়েন ফ্রিতে সংগ্রহ করুন এবং আপনার ফেসবুক, ইউটিউব ও টিকটক চ্যানেল আনলিমিটেড বুস্ট করুন।"
                    else
                        "100% Free! Claim infinite coins anytime to boost your YouTube, Facebook & TikTok channels.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 18.sp
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    coinPacks.forEach { (amount, packName) ->
                        Button(
                            onClick = { onClaimCoins(amount) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (amount >= 10000) CoinGold else DarkSurfaceVariant
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        tint = if (amount >= 10000) Color.Black else CoinGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "+$amount কয়েন",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (amount >= 10000) Color.Black else CoinGold
                                    )
                                }
                                Text(
                                    text = packName,
                                    fontSize = 12.sp,
                                    color = if (amount >= 10000) Color.Black else TextSecondary
                                )
                            }
                        }
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (language == "bn") "সম্পন্ন হয়েছে" else "Done",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
