package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Social Brand Colors
val YouTubeRed = Color(0xFFFF1744)
val YouTubeRedDark = Color(0xFFD50000)
val FacebookBlue = Color(0xFF1877F2)
val FacebookBlueDark = Color(0xFF0D5BB9)
val TikTokPink = Color(0xFFFE2C55)
val TikTokCyan = Color(0xFF25F4EE)
val TikTokDark = Color(0xFF121212)

// Accent and Utility Colors
val CoinGold = Color(0xFFFBBF24)
val CoinGoldGlow = Color(0xFFFDE68A)
val NeonCyan = Color(0xFF00F2FE)
val ElectricPurple = Color(0xFF8B5CF6)
val SuccessGreen = Color(0xFF10B981)

// Dark Theme Surfaces
val DarkBg = Color(0xFF090D16)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E2942)
val DarkBorder = Color(0xFF2E3D60)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Material 3 Color Scheme standard tokens
val PrimaryLight = Color(0xFF6366F1)
val OnPrimaryLight = Color.White
val PrimaryDark = Color(0xFF818CF8)
val OnPrimaryDark = Color(0xFF0F172A)

val SecondaryLight = Color(0xFF0284C7)
val SecondaryDark = Color(0xFF38BDF8)

val TertiaryLight = Color(0xFFE11D48)
val TertiaryDark = Color(0xFFFB7185)
