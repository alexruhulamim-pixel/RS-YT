package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.content.ViralToolsData
import com.example.ui.theme.CoinGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.YouTubeRed
import com.example.ui.viewmodel.GrowthViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ToolsScreen(
    viewModel: GrowthViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userStats by viewModel.userStats.collectAsState()
    val lang = userStats?.language ?: "bn"

    var selectedToolTab by remember { mutableIntStateOf(0) } // 0: Title Gen, 1: Hashtags, 2: Script Formula, 3: Thumbnail Checklist

    // Title generator state
    var topicKeyword by remember { mutableStateOf("") }
    var selectedPlatform by remember { mutableStateOf("YOUTUBE") }
    var generatedTitles by remember { mutableStateOf(ViralToolsData.generateViralTitles("ফেসবুক ও ইউটিউব গ্রোথ", "YOUTUBE")) }

    // Hashtags state
    var selectedHashtagPackId by remember { mutableStateOf(ViralToolsData.hashtagPacks.first().id) }

    // Checklist state
    val checkedChecklist = remember { mutableStateListOf<Int>() }

    fun copyToClipboard(text: String, successLabel: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Copied Text", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, successLabel, Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tool Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = if (lang == "bn") "ভাইরাল AI টুলস ও গ্রোথ ইঞ্জিন" else "Viral AI Growth Tools",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (lang == "bn")
                        "অ্যালগরিদমের পছন্দ অনুযায়ী টাইটেল, ট্রেন্ডিং হ্যাশট্যাগ এবং হাই-কনভার্টিং স্ক্রিপ্ট তৈরি করুন"
                    else
                        "Generate high-CTR hooks, trending hashtag packs, and retention scripts",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Sub Navigation Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    ToolTabChip(
                        title = if (lang == "bn") "টাইটেল জেনারেটর" else "Title Generator",
                        icon = Icons.Default.Title,
                        isSelected = selectedToolTab == 0,
                        onClick = { selectedToolTab = 0 }
                    )
                }
                item {
                    ToolTabChip(
                        title = if (lang == "bn") "ট্রেন্ডিং হ্যাশট্যাগ" else "Hashtag Superpack",
                        icon = Icons.Default.Tag,
                        isSelected = selectedToolTab == 1,
                        onClick = { selectedToolTab = 1 }
                    )
                }
                item {
                    ToolTabChip(
                        title = if (lang == "bn") "রিলস স্ক্রিপ্ট ব্লুপ্রিন্ট" else "Viral Script",
                        icon = Icons.Default.VideoLibrary,
                        isSelected = selectedToolTab == 2,
                        onClick = { selectedToolTab = 2 }
                    )
                }
                item {
                    ToolTabChip(
                        title = if (lang == "bn") "থাম্বনেইল চেকলিস্ট" else "CTR Checklist",
                        icon = Icons.Default.CheckCircle,
                        isSelected = selectedToolTab == 3,
                        onClick = { selectedToolTab = 3 }
                    )
                }
            }
        }

        // TOOL 1: VIRAL TITLE GENERATOR
        if (selectedToolTab == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = if (lang == "bn") "হাই-ক্লিক (High CTR) ভাইরাল টাইটেল তৈরি করুন" else "High-CTR Title Generator",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )

                        // Platform selection for title
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedPlatform = "YOUTUBE" },
                                color = if (selectedPlatform == "YOUTUBE") YouTubeRed else DarkSurfaceVariant
                            ) {
                                Text(
                                    text = "YouTube Video / Shorts",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedPlatform = "FACEBOOK" },
                                color = if (selectedPlatform == "FACEBOOK") FacebookBlue else DarkSurfaceVariant
                            ) {
                                Text(
                                    text = "Facebook Reels / Post",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }

                        // Keyword input
                        OutlinedTextField(
                            value = topicKeyword,
                            onValueChange = { topicKeyword = it },
                            placeholder = {
                                Text(
                                    if (lang == "bn")
                                        "আপনার ভিডিওর বিষয় লিখুন (যেমন: ফ্রি ফায়ার, বিরিয়ানি রেসিপি, ইসলামিক উক্তি)"
                                    else
                                        "Enter video topic (e.g., Free fire gameplay, Biryani recipe, Tech review)"
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("title_keyword_input"),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                generatedTitles = ViralToolsData.generateViralTitles(topicKeyword, selectedPlatform)
                                viewModel.recordAction("TITLE")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("generate_titles_btn")
                        ) {
                            Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == "bn") "ভাইরাল টাইটেল তৈরি করুন" else "Generate Viral Titles",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            items(generatedTitles) { titlePair ->
                val titleDisplay = if (lang == "bn") titlePair.first else titlePair.second
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SuccessGreen.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "CTR Score: 95%+",
                                    color = SuccessGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = {
                                        copyToClipboard(
                                            titleDisplay,
                                            if (lang == "bn") "টাইটেল কপি করা হয়েছে!" else "Title copied to clipboard!"
                                        )
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy",
                                        tint = NeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        viewModel.saveItem("TITLE", selectedPlatform, "Viral Title", titleDisplay)
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.BookmarkBorder,
                                        contentDescription = "Save",
                                        tint = CoinGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = titleDisplay,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            lineHeight = 20.sp
                        )

                        Text(
                            text = if (lang == "bn") titlePair.second else titlePair.first,
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // TOOL 2: TRENDING HASHTAGS
        if (selectedToolTab == 1) {
            val selectedPack = ViralToolsData.hashtagPacks.find { it.id == selectedHashtagPackId }
                ?: ViralToolsData.hashtagPacks.first()

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ViralToolsData.hashtagPacks) { pack ->
                        val isSelected = pack.id == selectedHashtagPackId
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedHashtagPackId = pack.id },
                            color = if (isSelected) NeonCyan else DarkSurfaceVariant
                        ) {
                            Text(
                                text = if (lang == "bn") pack.titleBn else pack.titleEn,
                                color = if (isSelected) Color.Black else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang == "bn") selectedPack.titleBn else selectedPack.titleEn,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "${selectedPack.category} • ${if (lang == "bn") "ভাইরাল স্কোর" else "Viral Score"}: ${selectedPack.popularityScore}%",
                                    color = NeonCyan,
                                    fontSize = 12.sp
                                )
                            }

                            Button(
                                onClick = {
                                    val fullTags = selectedPack.hashtags.joinToString(" ")
                                    copyToClipboard(
                                        fullTags,
                                        if (lang == "bn") "সকল হ্যাশট্যাগ কপি করা হয়েছে!" else "All hashtags copied!"
                                    )
                                    viewModel.recordAction("TAGS")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = YouTubeRed),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = if (lang == "bn") "সব কপি করুন" else "Copy All", fontSize = 12.sp, color = Color.White)
                            }
                        }

                        // Hashtag chips cloud
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            selectedPack.hashtags.forEach { tag ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = DarkSurfaceVariant,
                                    modifier = Modifier.clickable {
                                        copyToClipboard(
                                            tag,
                                            if (lang == "bn") "$tag কপি হয়েছে" else "Copied $tag"
                                        )
                                    }
                                ) {
                                    Text(
                                        text = tag,
                                        color = NeonCyan,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // TOOL 3: VIRAL SCRIPT BLUEPRINT
        if (selectedToolTab == 2) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = if (lang == "bn") "রিলস ও শর্টস ভাইরাল স্ক্রিপ্ট ফ্রেমওয়ার্ক" else "Viral 30-Sec Script Blueprint",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )

                        ScriptStepCard(
                            stepNumber = "1",
                            timeframe = "0 - 3 Sec",
                            title = if (lang == "bn") "শক ও কিউরিওসিটি হুক (The Hook)" else "Curiosity Hook",
                            desc = if (lang == "bn")
                                "প্রথম ৩ সেকেন্ডেই দর্শককে আটকান। উদাহরণ: 'আপনি কি জানেন এই ছোট ভুলের কারণে আপনার চ্যানেল ডাউন হচ্ছে?'"
                            else
                                "Stop the scroll immediately with a high-stakes question or unexpected statement.",
                            color = YouTubeRed
                        )

                        ScriptStepCard(
                            stepNumber = "2",
                            timeframe = "4 - 20 Sec",
                            title = if (lang == "bn") "কোর ভ্যালু ও দ্রুত সমাধান (Core Value)" else "Rapid Value Delivery",
                            desc = if (lang == "bn")
                                "বাজে কথা না বলে সরাসরি ২টি সমাধান বা দৃশ্য দেখান। স্ক্রিনে ফাস্ট পেসড কাট ও সাউন্ড এফেক্ট রাখুন।"
                            else
                                "Provide 2 direct, zero-fluff answers with fast-paced visual transitions.",
                            color = NeonCyan
                        )

                        ScriptStepCard(
                            stepNumber = "3",
                            timeframe = "21 - 25 Sec",
                            title = if (lang == "bn") "সাবস্ক্রাইব/ফলো কল টু অ্যাকশন (CTA)" else "Smart Subscribe CTA",
                            desc = if (lang == "bn")
                                "শুধু 'সাবস্ক্রাইব করুন' না বলে বলুন: 'পরবর্তী পর্বে দ্বিতীয় গোপন ট্রিক জানতে এখনই সাবস্ক্রাইব করে রাখুন!'"
                            else
                                "Give an incentive: 'Subscribe now so you don't miss Part 2 revealing the top algorithm secret!'",
                            color = SuccessGreen
                        )
                    }
                }
            }
        }

        // TOOL 4: THUMBNAIL & CTR CHECKLIST
        if (selectedToolTab == 3) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = if (lang == "bn") "আপলোড করার আগের থাম্বনেইল চেকলিস্ট (১০% CTR)" else "Pre-Upload 10%+ CTR Checklist",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (lang == "bn")
                                "প্রতিটি শর্ত নিশ্চিত করুন যাতে ইউটিউব ও ফেসবুক বেশি মানুষকে রেকমেন্ড করে।"
                            else
                                "Tick each box before publishing to ensure high recommendation volume.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )

                        val checklistItems = if (lang == "bn")
                            ViralToolsData.thumbnailChecklistItemsBn
                        else
                            ViralToolsData.thumbnailChecklistItemsEn

                        checklistItems.forEachIndexed { index, itemText ->
                            val isChecked = checkedChecklist.contains(index)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isChecked) DarkSurfaceVariant else Color.Transparent)
                                    .clickable {
                                        if (isChecked) checkedChecklist.remove(index) else checkedChecklist.add(index)
                                    }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = if (isChecked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (isChecked) SuccessGreen else TextMuted
                                )
                                Text(
                                    text = itemText,
                                    color = if (isChecked) TextPrimary else TextSecondary,
                                    fontSize = 13.sp,
                                    fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolTabChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = if (isSelected) NeonCyan else DarkSurfaceVariant,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.Black else TextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = title,
                color = if (isSelected) Color.Black else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
fun ScriptStepCard(
    stepNumber: String,
    timeframe: String,
    title: String,
    desc: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.2f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(text = stepNumber, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = timeframe, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text(text = desc, color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
    }
}
